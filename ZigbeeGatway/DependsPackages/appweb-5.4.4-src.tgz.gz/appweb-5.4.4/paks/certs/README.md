certs
===

Test certificates.

## Installation

    pak install certs

## Building

    me

## Get Pak

[https://embedthis.com/pak/](https://embedthis.com/pak/download.html)
