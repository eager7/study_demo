Embedthis O/S Dependent Layer
===

Licensing
---
See LICENSE.md for details.

### To Install

    pak install pak-osdep

Resources
---
  - [osdep GitHub repository](http://github.com/embedthis/osdep)
