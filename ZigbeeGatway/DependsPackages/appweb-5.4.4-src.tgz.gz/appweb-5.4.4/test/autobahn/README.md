Autobahn WebSockets Test Suite
===

This directory is used for the Autobahn WebSockets test suite.

    http://autobahn.ws/testsuite


Running
---
Run from the ../test directory via:

    wstest -m fuzzingclient -s ws/fuzzingclient.json
